=== Books ===
Contributors: pankaj bansal
Tags: books,isbn,author

Books Plugin is ready to use for everyone, who want to create custom post related to book information.

== Description ==

Books Plugin is used for add/update information regarding the books, author, featured image, ISBN, excerpt etc..

== Installation ==

1) Upload the Books plugin to your website, Activate it.
2) Books Menu Option will be displayed on administrator panel.
3) Books -> Authors -> Admin can add authors from this tab.
4) Books -> Add New -> Used for add new book.
5) Books -> All Books -> Used for listing all books






